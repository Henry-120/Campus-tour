import 'package:flutter/material.dart';

import '../constants/asset_paths.dart';
import '../login/game_button.dart';
import '../login/game_link_text.dart';
import '../login/google_image_button.dart';
import '../login/login_text_field.dart';

class WoodRegisterPanel extends StatelessWidget {
  const WoodRegisterPanel({
    super.key,
    required this.nameController,
    required this.emailController,
    required this.passwordController,
    required this.confirmController,
    required this.isLoading,
    required this.onRegister,
    required this.onGoogleSignIn,
    required this.onBackToLogin,
  });

  final TextEditingController nameController;
  final TextEditingController emailController;
  final TextEditingController passwordController;
  final TextEditingController confirmController;

  final bool isLoading;

  final VoidCallback onRegister;
  final VoidCallback onGoogleSignIn;
  final VoidCallback onBackToLogin;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 390,

      // 這裡不用太高，因為 Google button 會超出木板
      height: 680,

      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.center,
        children: [
          Positioned.fill(
            child: Image.asset(
              AssetPaths.rWoodBoard,
              fit: BoxFit.fill,
            ),
          ),

          Padding(
            padding: const EdgeInsets.fromLTRB(76, 72, 60, 42),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildLabel("Name"),
                const SizedBox(height: 6),
                LoginTextField(
                  controller: nameController,
                  hintText: "Enter your Name",
                  icon: Icons.person,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return "請輸入名稱";
                    }
                    return null;
                  },
                ),

                const SizedBox(height: 11),

                _buildLabel("Email"),
                const SizedBox(height: 6),
                LoginTextField(
                  controller: emailController,
                  hintText: "Enter your Email",
                  icon: Icons.email,
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return "請輸入 Email";
                    }

                    final emailRegex = RegExp(
                      r'^[\w\.-]+@([\w-]+\.)+[\w-]{2,4}$',
                    );

                    if (!emailRegex.hasMatch(value.trim())) {
                      return "Email 格式不正確";
                    }

                    return null;
                  },
                ),

                const SizedBox(height: 11),

                _buildLabel("Password"),
                const SizedBox(height: 6),
                LoginTextField(
                  controller: passwordController,
                  hintText: "Enter your Password",
                  icon: Icons.lock,
                  isPasswordField: true,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return "請輸入密碼";
                    }

                    if (value.length < 6) {
                      return "密碼至少需要 6 位";
                    }

                    return null;
                  },
                ),

                const SizedBox(height: 11),

                _buildLabel("Confirm"),
                const SizedBox(height: 6),
                LoginTextField(
                  controller: confirmController,
                  hintText: "Confirm Password",
                  icon: Icons.verified_user,
                  isPasswordField: true,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return "請再次輸入密碼";
                    }

                    if (value != passwordController.text) {
                      return "兩次密碼不一致";
                    }

                    return null;
                  },
                ),

                const SizedBox(height: 20),

                GameButton(
                  text: "REGISTER",
                  isLoading: isLoading,
                  onTap: isLoading ? null : onRegister,
                  bg: AssetPaths.buttonGreen,
                ),

                const SizedBox(height: 14),

                GameLinkText(
                  text: "-- OR REGISTRATION VIA --",
                  onTap: () {},
                  fontSize: 16,
                ),
              ],
            ),
          ),

          // Google button 跟木板重疊
          Positioned(
            bottom: 10,
            child: GoogleImageButton(
              imagePath: AssetPaths.googleLogo,
              size: 100,
              disabled: isLoading,
              onTap: onGoogleSignIn,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLabel(String text) {
    return Text(
      text,
      style: TextStyle(
        fontSize: 21,
        fontWeight: FontWeight.w900,
        color: Colors.white,
        shadows: [
          Shadow(
            offset: const Offset(2, 2),
            blurRadius: 1,
            color: Colors.black.withValues(alpha: 0.75),
          ),
        ],
      ),
    );
  }
}