import 'package:flutter/material.dart';

import '../constants/asset_paths.dart';
import 'game_button.dart';
import 'game_link_text.dart';
import 'login_text_field.dart';

class WoodLoginPanel extends StatelessWidget {
  const WoodLoginPanel({
    super.key,
    required this.emailController,
    required this.passwordController,
    required this.isLoading,
    required this.onLogin,
    required this.onRegister,
    required this.onForgotPassword
  });

  final TextEditingController emailController;
  final TextEditingController passwordController;
  final bool isLoading;
  final VoidCallback onLogin;
  final VoidCallback onRegister;
  final VoidCallback onForgotPassword;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 390,
      height: 560,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Positioned.fill(
            child: Image.asset(
              AssetPaths.woodBoard,
              fit: BoxFit.fill,
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(76, 72, 60, 42),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildLabel("Username"),
                const SizedBox(height: 8),
                LoginTextField(
                  controller: emailController,
                  hintText: "Enter your Username",
                  icon: Icons.eco,
                ),
                const SizedBox(height: 18),
                _buildLabel("Password"),
                const SizedBox(height: 8),
                LoginTextField(
                  controller: passwordController,
                  hintText: "Enter your Password",
                  icon: Icons.lock,
                  isPasswordField: true,
                ),
                const SizedBox(height: 28),
                GameButton(
                  text: "LOGIN",
                  isLoading: isLoading,
                  onTap: onLogin,
                  bg: AssetPaths.buttonGreen,
                ),
                const SizedBox(height: 14),
                GameButton(
                  text: "REGISTER",
                  onTap: onRegister,
                  bg: AssetPaths.buttonBlue,
                ),
                const SizedBox(height: 18),
                GameLinkText(
                  text: "Forgot Password?",
                  onTap: onForgotPassword,
                  fontSize: 18,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLabel(String text) {
    return Text(
      text,
      style: TextStyle(
        fontSize: 21,
        fontWeight: FontWeight.w900,
        color: Colors.white,
        shadows: [
          Shadow(
            offset: const Offset(2, 2),
            blurRadius: 1,
            color: Colors.black.withValues(alpha: 0.75),
          ),
        ],
      ),
    );
  }
}
