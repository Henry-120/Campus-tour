import 'package:flutter/material.dart';

class GameLinkText extends StatelessWidget {
  const GameLinkText({
    super.key,
    required this.text,
    required this.onTap,
    required this.fontSize,
  });

  final String text;
  final VoidCallback onTap;
  final double fontSize;


  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: TextStyle(
          fontSize: fontSize,
          height: 1.25,
          fontWeight: FontWeight.w900,
          color: const Color(0xFFB9F451),
          shadows: [
            Shadow(
              offset: const Offset(2, 2),
              blurRadius: 1,
              color: Colors.black.withValues(alpha: 0.75),
            ),
          ],
        ),
      ),
    );
  }
}