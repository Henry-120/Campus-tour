import 'package:flutter/material.dart';

class GameTitle extends StatelessWidget {
  const GameTitle({
    super.key,
    this.title = "AWAKENING",
  });

  final String title;

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 40,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.5,
            foreground: Paint()
              ..style = PaintingStyle.stroke
              ..strokeWidth = 8
              ..color = const Color(0xFF6B3515),
          ),
        ),
        Text(
          title,
          style: const TextStyle(
            fontSize: 40,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.5,
            color: Color(0xFFFFD36A),
            shadows: [
              Shadow(
                offset: Offset(0, 3),
                blurRadius: 0,
                color: Color(0xFF9A4F1D),
              ),
            ],
          ),
        ),
      ],
    );
  }
}