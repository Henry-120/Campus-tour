import 'package:flutter/material.dart';

class LoginTextField extends StatefulWidget {
  const LoginTextField({
    super.key,
    required this.controller,
    required this.hintText,
    required this.icon,
    this.isPasswordField = false,
    this.validator,
    this.keyboardType,
  });

  final TextEditingController controller;
  final String hintText;
  final IconData icon;
  final bool isPasswordField;
  final String? Function(String?)? validator;
  final TextInputType? keyboardType;

  @override
  State<LoginTextField> createState() => _LoginTextFieldState();
}

class _LoginTextFieldState extends State<LoginTextField> {
  late bool _obscureText;
  bool _isFocused = false;
  final FocusNode _focusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _obscureText = widget.isPasswordField;
    _focusNode.addListener(() {
      setState(() {
        _isFocused = _focusNode.hasFocus;
      });
    });
  }

  @override
  void dispose() {
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // 當前是否應該發光：外部指定為 true OR 內部取得焦點
    final bool shouldGlow = _isFocused;
    print(shouldGlow);

    return Container(
      height: 46,
      decoration: BoxDecoration(
        color: const Color(0xFF3B1E12).withValues(alpha: 0.92),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: shouldGlow ? const Color(0xFFB9F451) : const Color(0xFF1F100A),
          width: shouldGlow ? 2.5 : 2,
        ),
        boxShadow: shouldGlow
            ? [
          BoxShadow(
            color: const Color(0xFFB9F451).withValues(alpha: 0.7),
            blurRadius: 10,
            spreadRadius: 1,
          ),
        ]
            : [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.35),
            offset: const Offset(0, 3),
            blurRadius: 4,
          ),
        ],
      ),
      child: TextFormField(
        controller: widget.controller,
        focusNode: _focusNode,
        obscureText: _obscureText,
        validator: widget.validator,
        keyboardType: widget.keyboardType,
        textAlignVertical: TextAlignVertical.center,
        style: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: 16,
        ),
        cursorColor: const Color(0xFFB9F451),
        decoration: InputDecoration(
          prefixIcon: Icon(
            widget.icon,
            color: shouldGlow ? const Color(0xFFB9F451) : const Color(0xFFEEDCC8),
          ),
          suffixIcon: widget.isPasswordField
              ? IconButton(
            icon: Icon(
              _obscureText ? Icons.visibility : Icons.visibility_off,
              color: const Color(0xFFEEDCC8),
              size: 20,
            ),
            onPressed: () {
              setState(() {
                _obscureText = !_obscureText;
              });
            },
          )
              : null,
          hintText: widget.hintText,
          hintStyle: TextStyle(
            color: Colors.white.withValues(alpha: 0.45),
            fontWeight: FontWeight.bold,
            fontSize: 14,
          ),
          border: InputBorder.none,
          errorBorder: InputBorder.none,
          focusedErrorBorder: InputBorder.none,
          isDense: true,
          contentPadding: const EdgeInsets.symmetric(vertical: 13),
          errorStyle: const TextStyle(
            height: 0,
            fontSize: 0,
          ),
        ),
      ),
    );
  }
}
