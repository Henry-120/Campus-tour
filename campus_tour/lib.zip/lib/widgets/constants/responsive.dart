import 'package:flutter/material.dart';

class Responsive {
  static const double designWidth = 411.42857142857144;
  static const double designHeight = 914.2857142857143;

  static double scaleWidth(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return width / designWidth;
  }

  static double scaleHeight(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    return height / designHeight;
  }

  static double scale(BuildContext context) {
    final sw = scaleWidth(context);
    final sh = scaleHeight(context);

    // 取比較小的比例，避免橫向或短螢幕爆版
    final value = sw < sh ? sw : sh;

    // 限制縮放範圍，避免平板太大或小手機太小
    return value.clamp(0.82, 1.12);
  }

  static double w(BuildContext context, double value) {
    return value * scaleWidth(context);
  }

  static double h(BuildContext context, double value) {
    return value * scaleHeight(context);
  }

  static double s(BuildContext context, double value) {
    return value * scale(context);
  }
}